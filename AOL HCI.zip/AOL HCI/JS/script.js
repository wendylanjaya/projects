const sliderImages = [
    "../ASSETS/Kapal 3.jpg",
    "../ASSETS/Kapal 2.jpg",
    "../ASSETS/Kapal 1.jpg"
];

let index = 0;
const slider = document.getElementById("sliderImage");

document.getElementById("nextBtn").addEventListener("click", () => {
    index = (index + 1) % sliderImages.length;
    slider.src = sliderImages[index];
});

document.getElementById("prevBtn").addEventListener("click", () => {
    index = (index - 1 + sliderImages.length) % sliderImages.length;
    slider.src = sliderImages[index];
});

document.getElementById("subscribeForm").addEventListener("submit", function(e) {
    e.preventDefault();


function validateAll(){

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const gender = document.getElementById("gender").value
        const password = document.getElementById("password").value
        const age = parseInt(document.getElementById("age").value)
        const interest = document.getElementById("interest").value


        document.getElementById("errorName").innerText = "";
        document.getElementById("errorEmail").innerText = "";
        document.getElementById("errorPassword").innerText = "";
        document.getElementById("errorAge").innerText = "";
        document.getElementById("errorInterest").innerText = "";
        document.getElementById("message").innerText = "";

        
        //Cek validasi

        let isValid = true;

        if (name == "") {
            document.getElementById("errorName").innerText = "Nama harus diisi!";
            isValid = false;
        }else if (name.split(" ").length < 2) {
            document.getElementById("errorName").innerText = "Nama harus lebih dari satu kata!";
            isValid = false;
        }


        if (email == "") {
            document.getElementById("errorEmail").innerText = "Email harus diisi.";
            isValid = false;
        }else if (email.endsWith("@gmail.com")) {
            document.getElementById("errorEmail").innerText = "Email harus dengan '@gmail.com'!";
            isValid = false;
        }


        if (password.length < 6) {
            document.getElementById("errorPassword").innerText = "Kata sandi minimal 6 karakter.";
            isValid = false;
        }


        if (isNaN(age) || age < 17) {
            document.getElementById("errorAge").innerText = "Usia minimal 17 tahun.";
            isValid = false;
        }


        if (interest == "") {
            document.getElementById("errorInterest").innerText = "Pilih jenis kapal favorit Anda.";
            isValid = false;
        }


        if (isValid) {
            document.getElementById("message").innerText = "Berhasil berlangganan!";
            document.getElementById("subscribeForm").reset();
        }
    }
});
